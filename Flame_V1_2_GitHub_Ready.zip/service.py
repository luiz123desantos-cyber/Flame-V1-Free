"""Local-only Flame V1 server, with clean shutdown."""
import secrets
import threading
from http.server import ThreadingHTTPServer
from flame_core import Controller, make_handler

class FlameService:
    def __init__(self, port=15700):
        self.port=port
        self.server=None
        self.controller=None
        self.thread=None
    def start(self, bridge=None):
        if self.server: return self.url
        if bridge is None:
            from windows_bridge import WindowsBridge
            bridge=WindowsBridge()
        controller=Controller(bridge)
        controller.scan()
        token=secrets.token_urlsafe(32)
        server=ThreadingHTTPServer(('127.0.0.1',self.port),make_handler(controller,token))
        server.daemon_threads=True
        try:
            controller.start()
            thread=threading.Thread(target=server.serve_forever,kwargs={'poll_interval':0.1},daemon=True,name='Flame-Web')
            thread.start()
        except BaseException:
            server.server_close()
            controller.shutdown()
            raise
        self.controller,self.server,self.thread=controller,server,thread
        return self.url
    @property
    def url(self):
        return 'http://127.0.0.1:%d/' % (self.server.server_port if self.server else self.port)
    def stop(self):
        server,controller,thread=self.server,self.controller,self.thread
        self.server=self.controller=self.thread=None
        if server:
            server.shutdown();server.server_close()
        if controller: controller.shutdown()
        if thread and thread.is_alive(): thread.join(timeout=1.5)
