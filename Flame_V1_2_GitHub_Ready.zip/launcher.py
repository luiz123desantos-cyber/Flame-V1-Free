"""Flame V1 Free — Windows launcher GUI and local web controller.
The loader does not attach to the game process or hide from Windows.
"""
from __future__ import annotations
import sys, threading, tkinter as tk, webbrowser
from pathlib import Path
from PIL import Image, ImageTk, ImageDraw, ImageFilter

ROOT=Path(getattr(sys,'_MEIPASS',Path(__file__).resolve().parent))
W,H=860,540
BG='#101017'
ORANGE='#FF834B'
MUTED='#9DA0B2'

class FlameLauncher:
    def __init__(self,root):
        self.root=root
        self.root.title('Flame V1 — Free Edition')
        self.root.geometry(f'{W}x{H}+{max(0,(root.winfo_screenwidth()-W)//2)}+{max(0,(root.winfo_screenheight()-H)//2)}')
        self.root.resizable(False,False)
        self.root.configure(bg=BG)
        try:self.root.iconbitmap(str(ROOT/'assets'/'flame.ico'))
        except Exception:pass
        self.root.protocol('WM_DELETE_WINDOW',self.close)
        try:
            with Image.open(ROOT/'assets'/'flame_background.png') as img:
                b=img.convert('RGBA').resize((W,H),Image.Resampling.LANCZOS)
            draw=ImageDraw.Draw(b,'RGBA')
            draw.rounded_rectangle((74,59,786,488),radius=30,fill=(14,16,23,220),outline=(255,255,255,44),width=2)
            draw.rounded_rectangle((92,76,150,134),radius=17,fill=(255,115,53,36),outline=(255,145,81,125),width=2)
            self.back=ImageTk.PhotoImage(b)
        except Exception as exc:
            raise RuntimeError(f'Recurso visual ausente: assets/flame_background.png ({exc})')
        self.cv=tk.Canvas(root,width=W,height=H,highlightthickness=0,bd=0,bg=BG)
        self.cv.pack()
        self.cv.create_image(0,0,image=self.back,anchor='nw')
        self.cv.create_text(120,104,text='F',fill='#FF9054',font=('Segoe UI',24,'bold'))
        self.cv.create_text(168,100,text='FLAME',fill='#FFFFFF',font=('Segoe UI',17,'bold'),anchor='w')
        self.cv.create_text(168,127,text='V1.2   /   FREE EDITION',fill='#F79C65',font=('Segoe UI',9,'bold'),anchor='w')
        self.cv.create_text(739,102,text='●  LOCAL',fill='#91E9B7',font=('Segoe UI',10,'bold'),anchor='e')
        self.cv.create_text(W//2,202,text='AUTO CLICKER',fill='#FAF7F5',font=('Segoe UI',39,'bold'))
        self.cv.create_text(W//2,249,text='Seu jogo. Seus controles.',fill='#F9AC84',font=('Segoe UI',17))
        self.cv.create_text(W//2,286,text='LMB + RMB   •   Lunar / Vanilla   •   F11 automático',fill=MUTED,font=('Segoe UI',11))
        self.cv.create_rectangle(246,328,614,391,fill='#F77535',outline='#FF995A',width=2,tags='start')
        self.cv.create_text(W//2,360,text='INICIAR  ↗',font=('Segoe UI',18,'bold'),fill='#FFFFFF',tags='start')
        self.cv.tag_bind('start','<Button-1>',lambda _e:self.start())
        self.cv.tag_bind('start','<Enter>',lambda _e:self.cv.config(cursor='hand2'))
        self.cv.tag_bind('start','<Leave>',lambda _e:self.cv.config(cursor=''))
        self.cv.create_text(W//2,422,text='Configure o auto clicker no seu navegador',font=('Segoe UI',10),fill='#B9B9C8')
        self.cv.create_text(W//2,460,text='FLAME V1.2 FREE  ·  WINDOWS 10/11',font=('Segoe UI',9,'bold'),fill='#898799')
        self.status=self.cv.create_text(W//2,310,text='',font=('Segoe UI',10,'bold'),fill='#FFB798')
        self.service=None
        self.starting=False
        self.started=False
        self.closing=False
        self.steps=['VERIFICANDO RECURSOS LOCAIS','INICIALIZANDO SERVIDOR LOCAL']
        self.root.after(250,self.verify)

    def verify(self):
        missing=[p for p in ('ui/index.html','ui/style.css','ui/app.js','assets/flame_background.png') if not (ROOT/p).is_file()]
        if missing:
            self.cv.itemconfig(self.status,text='Arquivos ausentes: '+', '.join(missing))
        elif sys.platform != 'win32':
            self.cv.itemconfig(self.status,text='Prévia do launcher — funcionamento disponível no Windows')
        else:
            self.cv.itemconfig(self.status,text='RECURSOS PRONTOS • SEM DOWNLOADS')
    def update_status(self,message):
        self.cv.itemconfig(self.status,text=message)
    def start(self):
        if self.closing: return
        if self.started:
            if self.service:webbrowser.open(self.service.url,new=2)
            return
        if self.starting:return
        missing=[p for p in ('ui/index.html','ui/style.css','ui/app.js') if not (ROOT/p).is_file()]
        if missing:
            self.update_status('Faltam arquivos do painel: '+', '.join(missing));return
        if sys.platform!='win32':
            self.update_status('Este programa executa cliques somente no Windows');return
        self.starting=True
        self.update_status(self.steps[1])
        threading.Thread(target=self._launch,daemon=True,name='Flame-Startup').start()
    def _launch(self):
        try:
            from service import FlameService
            srv=FlameService(port=15700)
            srv.start()
            self.root.after(0,lambda:self._ready(srv))
        except Exception as exc:
            msg=str(exc)
            if any(t in msg for t in ('10048','Address already in use','Only one usage')):
                msg='Porta 15700 ocupada. Feche o Flame/Love157 anterior.'
            self.root.after(0,lambda m=msg:self._fail(m))
    def _ready(self,srv):
        if self.closing:
            srv.stop();return
        self.service=srv
        self.started=True
        self.starting=False
        self.cv.itemconfig(self.status,text='PAINEL ONLINE • localhost:15700',fill='#91E9B7')
        self.cv.itemconfig(self.cv.find_withtag('start')[-1],text='ABRIR PAINEL  ↗')
        webbrowser.open(srv.url,new=2)
    def _fail(self,msg):
        self.starting=False
        self.cv.itemconfig(self.status,text='ERRO: '+msg[:90],fill='#FFC8B9')
    def close(self):
        if self.closing:return
        self.closing=True
        self.cv.itemconfig(self.status,text='ENCERRANDO...')
        threading.Thread(target=self._shutdown,daemon=True).start()
    def _shutdown(self):
        if self.service:self.service.stop()
        try:self.root.after(0,self.root.destroy)
        except RuntimeError:pass

def main():
    root=tk.Tk()
    try: FlameLauncher(root)
    except Exception as exc:
        from tkinter import messagebox
        messagebox.showerror('Flame V1 Free',str(exc),parent=root)
        root.destroy();return
    root.mainloop()
if __name__=='__main__':main()
