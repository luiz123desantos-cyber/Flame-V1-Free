"""FLAME V1 FREE: dual clicker with automatic fullscreen HWND recovery.

No memory injection. Works with OS mouse events only when target window has focus.
"""
from __future__ import annotations

import json
import os
import secrets
import random
import sys
import threading
import time
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse

ROOT = Path(getattr(sys, '_MEIPASS', Path(__file__).resolve().parent))
HOST = '127.0.0.1'
PORT = 15700
PROFILE_LIMITS = {'legit': (1, 20), 'blatant': (1, 40)}

def click_interval(cps, click_profile, rng=None):
    """Intervalo por perfil: jitter na temporização, sem alegar evadir anticheats."""
    if click_profile not in PROFILE_LIMITS:
        raise ValueError('Perfil de clique inválido.')
    lower, upper = PROFILE_LIMITS[click_profile]
    if type(cps) is not int or not (lower <= cps <= upper):
        raise ValueError(f'CPS do modo {click_profile}: {lower} a {upper}.')
    rng = rng or random.SystemRandom()
    factor = rng.uniform(.83, 1.17) if click_profile == 'legit' else rng.uniform(.97, 1.03)
    return max(.007, factor / cps)

# Apenas preferências criadas pelo próprio Flame, sem exclusão de logs do sistema.
PREFERENCES_FILE = Path(os.environ.get('LOCALAPPDATA', str(Path.home() / 'AppData' / 'Local'))) / 'FlameV1Free' / 'preferences.json'


class Controller:
    def __init__(self, bridge, preferences_path=None):
        self.bridge = bridge
        self.lock = threading.RLock()
        self.windows = []
        self.selected_hwnd = None
        self.selected_pid = None
        self.manual_window = None
        self.binding_generation = 0
        self.target_client_hint = ''
        self.target_exe = ''
        self.recovering = False
        self.armed = False
        self.left_enabled, self.right_enabled = True, True
        self.left_cps, self.right_cps = 10, 10
        self.mode = 'sendinput'
        self.click_profile = 'legit'
        self.manual_pause = False
        self.active_left = self.active_right = False
        self.clicks_left = self.clicks_right = 0
        self.error = ''
        self.notice = ''
        self._stopping = threading.Event()
        self._worker = None
        self.preferences_path = Path(preferences_path) if preferences_path is not None else (PREFERENCES_FILE if sys.platform == 'win32' else None)
        self._load_preferences()

    def _load_preferences(self):
        path = self.preferences_path
        if not path or not path.is_file():
            return
        try:
            data = json.loads(path.read_text(encoding='utf-8'))
            if type(data) is not dict: return
            for field in ('left_cps', 'right_cps'):
                n = data.get(field)
                if type(n) is int and 1 <= n <= 40: setattr(self, field, n)
            if data.get('click_profile') in PROFILE_LIMITS:
                self.click_profile = data['click_profile']
            low, high = PROFILE_LIMITS[self.click_profile]
            self.left_cps = max(low, min(high, self.left_cps))
            self.right_cps = max(low, min(high, self.right_cps))
            for field in ('left_enabled', 'right_enabled'):
                v = data.get(field)
                if type(v) is bool: setattr(self, field, v)
            if data.get('mode') in ('sendinput', 'messages'): self.mode = data['mode']
        except (OSError, ValueError, UnicodeError):
            pass  # Prefere os padrões quando há configuração corrompida.

    def _save_preferences(self):
        path = self.preferences_path
        if path is None: return
        with self.lock:
            data = {field: getattr(self, field) for field in (
                'left_cps', 'right_cps', 'left_enabled', 'right_enabled',
                'click_profile', 'mode')}
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
            temp = path.with_name(path.name + '.tmp')
            temp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')
            temp.replace(path)
        except OSError as exc:
            with self.lock: self.notice = f'Preferências não foram salvas: {exc}'

    def reset_local_data(self):
        """Reseta Flame e somente seu próprio preferences.json. Não toca em logs do Windows."""
        self.stop()
        with self.lock:
            self.left_enabled = self.right_enabled = True
            self.left_cps = self.right_cps = 10
            self.mode = 'sendinput'
            self.click_profile = 'legit'
            self.manual_pause = False
            self.clicks_left = self.clicks_right = 0
            self.notice = 'Preferências e contadores do Flame redefinidos. Logs do Windows não foram alterados.'
        path = self.preferences_path
        if path is not None:
            try:
                path.unlink(missing_ok=True)
                try: path.parent.rmdir()
                except OSError: pass  # Não remover a pasta se tiver outros arquivos.
            except OSError as exc:
                with self.lock: self.error = f'Não foi possível excluir preferências: {exc}'
                return False
        return True

    def scan(self):
        """Refresh detected games without disarming on an F11 HWND change.

        Critical invariant: never silently migrate to a different PID.
        If this process has no visible window, pause until it reappears.
        """
        found = self.bridge.list_game_windows()
        with self.lock:
            old_hwnd, old_pid = self.selected_hwnd, self.selected_pid
            manual = self.manual_window
            hint = self.target_client_hint
            image = self.target_exe

        # The selected game may have replaced its window in fullscreen mode,
        # even with a blank title. Recover only by the SAME process ID.
        recovered = (self.bridge.recover_window(old_pid, old_hwnd)
                     if old_pid is not None else None)
        if recovered and image and recovered['exe'] and image.casefold() != recovered['exe'].casefold():
            # PID reuse or a different app, never silently retarget it.
            recovered = None
        if recovered:
            if not recovered['title']:
                recovered['title'] = 'Minecraft em tela cheia (sem título)'
            if not recovered['auto'] and hint:
                recovered['client'] = hint
            # Replace an existing discovery row as well: that row may have
            # a blank title/client while the recovered row carries our hint.
            found = [w for w in found if w['hwnd'] != recovered['hwnd']]
            found.insert(0, recovered)

        if manual and self.bridge.valid_window(manual['hwnd'], manual['pid']):
            if not any(w['hwnd'] == manual['hwnd'] for w in found):
                found.insert(0, manual)

        with self.lock:
            # A manual binding/API update may have occurred during enumeration.
            if (self.selected_hwnd, self.selected_pid) != (old_hwnd, old_pid):
                return list(self.windows)
            self.windows = found
            current = next((w for w in found if w['hwnd'] == old_hwnd and w['pid'] == old_pid), None)
            replacement = recovered or current
            if replacement:
                if old_hwnd != replacement['hwnd']:
                    self.selected_hwnd = replacement['hwnd']
                    self.selected_pid = replacement['pid']
                    self.binding_generation += 1
                    self.notice = 'F11 detectado: janela do jogo atualizada automaticamente.'
                    self.error = ''
                self.recovering = False
                if not self.target_client_hint:
                    self.target_client_hint = replacement['client']
                if not self.target_exe:
                    self.target_exe = replacement['exe']
                if self.manual_window and self.manual_window['pid'] == replacement['pid']:
                    self.manual_window = replacement
            elif old_pid is not None:
                # Do NOT choose a different game/PID by accident or turn off.
                # The input worker will see no focus on the old PID and pause.
                self.recovering = True
                self.notice = 'Aguardando a janela do Minecraft voltar após F11...'
                if self.manual_window and self.manual_window['pid'] != old_pid:
                    self.manual_window = None
            else:
                # Initial scan may propose a window, but never auto-arm.
                self.selected_hwnd = found[0]['hwnd'] if found else None
                self.selected_pid = found[0]['pid'] if found else None
                self.target_client_hint = found[0]['client'] if found else ''
                self.target_exe = found[0]['exe'] if found else ''
                self.recovering = False
            return list(self.windows)

    def bind_foreground(self):
        w = self.bridge.current_foreground_info()
        if not w:
            with self.lock:
                self.error = 'Nenhuma janela válida em primeiro plano. Entre no mundo do Minecraft e pressione F9.'
            return False
        with self.lock:
            self.manual_window = w
            self.binding_generation += 1
            self.selected_hwnd, self.selected_pid = w['hwnd'], w['pid']
            self.target_client_hint = w['client']
            self.target_exe = w['exe']
            self.recovering = False
            self.armed = False  # Always require PRONTO after new binding.
            self.active_left = self.active_right = False
            self.notice = f"F9: janela '{w['title']}' vinculada. Volte ao painel e clique PRONTO."
            self.error = ''
        self.scan()
        return True

    def _target_info(self):
        return next((w for w in self.windows if w['hwnd'] == self.selected_hwnd), None)

    def state(self):
        with self.lock:
            w = self._target_info()
            return {
                'recovering': self.recovering,
                'armed': self.armed, 'active_left': self.active_left, 'active_right': self.active_right,
                'selected_hwnd': self.selected_hwnd, 'selected_pid': self.selected_pid,
                'binding_generation': self.binding_generation,
                'target_title': w['title'] if w else '', 'target_client': w['client'] if w else '',
                'windows': list(self.windows), 'left_enabled': self.left_enabled,
                'right_enabled': self.right_enabled, 'left_cps': self.left_cps,
                'right_cps': self.right_cps, 'mode': self.mode, 'manual_pause': self.manual_pause,
                'click_profile': self.click_profile,
                'clicks_left': self.clicks_left, 'clicks_right': self.clicks_right,
                'error': self.error, 'notice': self.notice,
                'foreground': bool(w and self.bridge.foreground_matches(w['hwnd'], w['pid'])),
            }

    def configure(self, hwnd, left_cps, right_cps, left_enabled, right_enabled, mode, click_profile='legit'):
        if type(hwnd) is not int or hwnd <= 0:
            raise ValueError('Selecione uma janela ou vincule pelo F9.')
        if click_profile not in PROFILE_LIMITS:
            raise ValueError('Escolha Legit ou Blatant.')
        lower, upper = PROFILE_LIMITS[click_profile]
        if any(type(n) is not int or not lower <= n <= upper for n in (left_cps, right_cps)):
            raise ValueError(f'CPS do modo {click_profile}: {lower} a {upper}.')
        if type(left_enabled) is not bool or type(right_enabled) is not bool:
            raise ValueError('Opção de botão inválida.')
        if not (left_enabled or right_enabled):
            raise ValueError('Ative pelo menos um botão.')
        if mode not in ('sendinput', 'messages'):
            raise ValueError('Método de entrada inválido.')
        self.scan()
        with self.lock:
            w = next((w for w in self.windows if w['hwnd'] == hwnd), None)
            if not w:
                raise ValueError('Janela não encontrada. Atualize ou vincule pelo F9.')
            self.selected_hwnd, self.selected_pid = w['hwnd'], w['pid']
            self.target_client_hint = w['client']
            self.target_exe = w['exe']
            self.recovering = False
            self.left_cps, self.right_cps = left_cps, right_cps
            self.left_enabled, self.right_enabled, self.mode = left_enabled, right_enabled, mode
            self.click_profile = click_profile
            self.manual_pause = False
            self.armed = True
            self.error = ''
            self.notice = f"{click_profile.upper()} ativado para {w['client']} • {w['title']}"
        self._save_preferences()

    def toggle(self):
        with self.lock:
            if self.selected_hwnd is None:
                self.error = 'Selecione a janela do Minecraft primeiro.'
                return
            self.armed = not self.armed
            if not self.armed:
                self.active_left = self.active_right = False

    def pause_left(self):
        with self.lock:
            self.manual_pause = not self.manual_pause

    def stop(self):
        with self.lock:
            self.armed = False
            self.active_left = self.active_right = False
            self.error = ''

    def run(self):
        next_left = next_right = time.perf_counter()
        prev_f6 = prev_f7 = prev_f8 = prev_f9 = False
        was_left = was_right = False
        prev_hwnd, prev_mode = None, 'sendinput'
        last_scan = 0
        while not self._stopping.is_set():
            now = time.perf_counter()
            if now - last_scan > 0.65:
                try:
                    self.scan()
                except Exception as e:
                    with self.lock:
                        self.error = f'Erro ao buscar clientes: {e}'
                last_scan = now
            f6 = self.bridge.held(self.bridge.VK_F6)
            f7 = self.bridge.held(self.bridge.VK_F7)
            f8 = self.bridge.held(self.bridge.VK_F8)
            f9 = self.bridge.held(self.bridge.VK_F9)
            if f8 and not prev_f8:
                self.stop()
            elif f9 and not prev_f9:
                self.bind_foreground()
            elif f6 and not prev_f6:
                self.toggle()
            if f7 and not prev_f7:
                self.pause_left()
            prev_f6, prev_f7, prev_f8, prev_f9 = f6, f7, f8, f9

            with self.lock:
                active_config = self.armed
                hwnd, pid, mode = self.selected_hwnd, self.selected_pid, self.mode
                le, re = self.left_enabled, self.right_enabled
                lcps, rcps = self.left_cps, self.right_cps
                click_profile = self.click_profile
                pause = self.manual_pause
            focused = bool(active_config and hwnd and pid and self.bridge.foreground_matches(hwnd, pid))
            left_down = focused and self.bridge.held(self.bridge.VK_LBUTTON)
            right_down = focused and self.bridge.held(self.bridge.VK_RBUTTON)
            left_on = bool(left_down and le and not pause)
            right_on = bool(right_down and re)

            # If previous event mode/target changes, release before switching streams.
            if (was_left or was_right) and (mode != prev_mode or hwnd != prev_hwnd):
                try:
                    # PostMessage is tied to a specific HWND. Release the old
                    # virtual button state; SendInput is global, so avoid a
                    # synthetic mouse-UP just because fullscreen changed HWND.
                    if prev_mode == 'messages':
                        if was_left: self.bridge.release(self.bridge.VK_LBUTTON, prev_hwnd, prev_mode)
                        if was_right: self.bridge.release(self.bridge.VK_RBUTTON, prev_hwnd, prev_mode)
                except Exception: pass
                was_left = was_right = False
            if left_on and now >= next_left:
                try:
                    self.bridge.click_pulse(self.bridge.VK_LBUTTON, hwnd, mode)
                    with self.lock: self.clicks_left += 1
                except Exception as e:
                    self.stop()
                    with self.lock: self.error = f'Erro no clique esquerdo: {e}'
                next_left = now + click_interval(lcps, click_profile)
            if right_on and now >= next_right:
                try:
                    self.bridge.click_pulse(self.bridge.VK_RBUTTON, hwnd, mode)
                    with self.lock: self.clicks_right += 1
                except Exception as e:
                    self.stop()
                    with self.lock: self.error = f'Erro no clique direito: {e}'
                next_right = now + click_interval(rcps, click_profile)
            # IMPORTANT: skip release when button is still physically held.
            # If no longer held, explicitly release to avoid stuck synthetic input.
            if was_left and not left_on and not left_down and (prev_mode == 'messages' or focused):
                try: self.bridge.release(self.bridge.VK_LBUTTON, prev_hwnd, prev_mode)
                except Exception: pass
            if was_right and not right_on and not right_down and (prev_mode == 'messages' or focused):
                try: self.bridge.release(self.bridge.VK_RBUTTON, prev_hwnd, prev_mode)
                except Exception: pass
            if not left_on: next_left = now
            if not right_on: next_right = now
            was_left, was_right, prev_hwnd, prev_mode = left_on, right_on, hwnd, mode
            with self.lock:
                self.active_left, self.active_right = left_on and self.armed, right_on and self.armed
            time.sleep(.006)
        for button, was in ((self.bridge.VK_LBUTTON, was_left), (self.bridge.VK_RBUTTON, was_right)):
            if was:
                try: self.bridge.release(button, prev_hwnd, prev_mode)
                except Exception: pass

    def start(self):
        self._worker = threading.Thread(target=self.run, daemon=True, name='FlameV1AutoClick')
        self._worker.start()

    def shutdown(self):
        self._stopping.set()
        self.stop()
        if self._worker:
            self._worker.join(timeout=2)


def make_handler(controller, token):
    class Handler(BaseHTTPRequestHandler):
        server_version = 'Flame/1.2'
        def log_message(self, *args): pass
        def respond(self, status, payload, content_type='application/json; charset=utf-8'):
            if isinstance(payload, (dict, list)):
                data = json.dumps(payload, ensure_ascii=False).encode('utf-8')
            elif isinstance(payload, str):
                data = payload.encode('utf-8')
            else:
                data = payload
            self.send_response(status)
            self.send_header('Content-Type', content_type)
            self.send_header('Content-Length', str(len(data)))
            self.send_header('Cache-Control', 'no-store')
            self.send_header('X-Content-Type-Options', 'nosniff')
            self.send_header('X-Frame-Options', 'DENY')
            self.send_header('Content-Security-Policy', "default-src 'self'; connect-src 'self'; script-src 'self'; style-src 'self'; base-uri 'none'; frame-ancestors 'none'")
            self.end_headers()
            self.wfile.write(data)
        def do_GET(self):
            path = urlparse(self.path).path
            if path == '/':
                html = (ROOT / 'ui' / 'index.html').read_text(encoding='utf-8').replace('__FLAME_TOKEN__', token)
                return self.respond(200, html, 'text/html; charset=utf-8')
            if path == '/app.js':
                return self.respond(200, (ROOT / 'ui' / 'app.js').read_bytes(), 'application/javascript; charset=utf-8')
            if path == '/style.css':
                return self.respond(200, (ROOT / 'ui' / 'style.css').read_bytes(), 'text/css; charset=utf-8')
            if path == '/health':
                return self.respond(200, {'name':'Flame V1 Free','service':'online'})
            if path == '/api/status':
                return self.respond(200, controller.state())
            if path == '/api/scan':
                controller.scan()
                return self.respond(200, controller.state())
            return self.respond(404, {'error':'Não encontrado.'})
        def do_POST(self):
            origin = self.headers.get('Origin', '')
            if origin and origin != f'http://{HOST}:{self.server.server_port}':
                return self.respond(403, {'error':'Origem não autorizada.'})
            if self.headers.get('X-Flame-Token', '') != token:
                return self.respond(403, {'error':'Token inválido.'})
            try:
                count = int(self.headers.get('Content-Length', '0'))
                if count < 1 or count > 4096:
                    return self.respond(400, {'error':'Tamanho inválido.'})
                body = json.loads(self.rfile.read(count).decode('utf-8'))
                if not isinstance(body, dict):
                    raise ValueError('Configuração inválida.')
                path = urlparse(self.path).path
                if path == '/api/ready':
                    controller.configure(body.get('hwnd'), body.get('left_cps'), body.get('right_cps'),
                                         body.get('left_enabled'), body.get('right_enabled'), body.get('mode'),
                                         body.get('click_profile', 'legit'))
                elif path == '/api/stop':
                    controller.stop()
                elif path == '/api/reset-local':
                    if not controller.reset_local_data():
                        return self.respond(500, {'error': controller.state()['error']})
                elif path == '/api/pause':
                    controller.pause_left()
                else:
                    return self.respond(404, {'error':'Não encontrado.'})
                return self.respond(200, controller.state())
            except (ValueError, TypeError, json.JSONDecodeError) as e:
                return self.respond(400, {'error':str(e)})
    return Handler


def main():
    if sys.platform != 'win32':
        print('FLAME V1 FREE requer Windows 10/11.')
        return 1
    from windows_bridge import WindowsBridge
    bridge = WindowsBridge()
    ctrl = Controller(bridge)
    ctrl.scan()
    port = int(os.environ.get('FLAME_PORT', PORT))
    token = secrets.token_urlsafe(32)
    try:
        server = ThreadingHTTPServer((HOST, port), make_handler(ctrl, token))
    except OSError as e:
        print(f'Porta {port} indisponível. Feche o FlameV1 anterior. {e}')
        return 2
    ctrl.start()
    url = f'http://{HOST}:{port}/'
    print('=' * 60)
    print(' FLAME V1 FREE - AUTO F11 / VANILLA / LUNAR / OUTROS')
    print('=' * 60)
    print(' F6 = Liga/desliga | F7 = Pausa esquerdo | F8 = PARAR')
    print(' F11 = JANELA/TELA CHEIA: reconexao automatica por PID')
    print(' F9 = Vincular janela manualmente (opcional)')
    print(' Segure mouse esquerdo/direito para ativar no jogo selecionado.')
    print(' Sem JDK, sem DLL, sem leitura de memoria.')
    print(f' Painel: {url}')
    print('=' * 60)
    webbrowser.open(url)
    try:
        server.serve_forever(poll_interval=.1)
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
        ctrl.shutdown()
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
