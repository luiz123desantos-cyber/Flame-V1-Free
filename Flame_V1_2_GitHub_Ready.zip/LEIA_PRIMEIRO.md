# FLAME V1.2 FREE — Auto Clicker + Instalador

## O que mudou

- **Legit**: 1–20 CPS, intervalos variáveis (±17% por clique) que imitam um ritmo irregular de jitter click. **Não** garante aparência humana, compatibilidade ou invisibilidade a sistemas de detecção.
- **Blatant**: 1–40 CPS, intervalos mais estáveis (±3%), com velocidade maior.
- LMB e RMB independentes, com os dois perfis disponíveis para cada lado.
- A proteção experimental baseada em cursor visível/inventário foi **removida**; o Auto Clicker só pausa automaticamente se o jogo perder o foco, ou pelas teclas F7/F8.
- Mantidas: detecção de clientes, F11 automático pelo mesmo PID, atalhos F6–F9, painel em http://127.0.0.1:15700.
- No painel há **Limpeza local**: para os cliques, apaga **somente** o arquivo `%LOCALAPPDATA%\FlameV1Free\preferences.json` e reseta contadores. Não remove registros de auditoria do Windows.
- Removida a frase de rodapé solicitada.

## Como gerar o `.exe` portátil no seu Windows

1. Descompacte **o ZIP inteiro** numa pasta local, não execute dentro do ZIP.
2. Feche versões anteriores do Flame (inclusive o `.exe` no Gerenciador de Tarefas), para liberar a porta 15700.
3. Execute `GERAR_EXE.cmd`.
4. Se as ferramentas de **compilação** (PyInstaller/Pillow) faltarem, o script pergunta **S/N** antes de instalar.
5. Resultado: `dist\FlameV1_Free.exe` (PyInstaller onefile).

**Python só é necessário na máquina que compila o projeto.** O `.exe` gerado contém o interpretador e os arquivos do painel; o PC de destino não precisa instalar Python nem executar downloads automáticos. Não são incluídos DLLs externas de injeção.

## Como gerar um instalador `.exe`

1. Primeiro gere `dist\FlameV1_Free.exe`.
2. Execute `CRIAR_INSTALADOR.cmd`.
3. Se não houver **Inno Setup 6**, o script pergunta **S/N** e tenta instalar com `winget` pela origem oficial do Windows. Caso `winget` não esteja disponível, abre a página oficial https://jrsoftware.org/isdl.php para instalação manual.
4. Resultado: `installer\Flame_V1_Free_Setup.exe`.
5. Em um Windows 10/11 x64, o instalador oferece **atalho na área de trabalho** (marcado por padrão), menu Iniciar e desinstalador normal.

O instalador **já contém** o `FlameV1_Free.exe` completo: não exige download de Python ou das dependências de interface no computador de quem instala.

## Como usar

- Inicie o Flame e clique **ABRIR PAINEL** para usar o Chrome.
- Selecione a janela do Minecraft / Lunar no painel, escolha o perfil Legit ou Blatant, ajuste LMB/RMB, clique **PRONTO — ATIVAR**.
- Segure o botão físico escolhido na janela do Minecraft em foco.
- Atalhos: **F6** ativa/desativa; **F7** pausa apenas LMB; **F8** para tudo; **F9** vincula a janela do jogo em primeiro plano.
- Se o F11 recriar a janela, o Flame procura outra janela **do mesmo processo** antes de retomar.
- Alguns clientes de Minecraft não aceitam cliques sintéticos ou podem limitar a taxa efetiva; não há garantia universal de compatibilidade.

## Limitações e segurança

- O modo **Mensagens para janela** continua experimental, sem garantia em Lunar ou clientes com Raw Input.
- O modo Legit apenas altera o ritmo; não elimina detecção.
- O botão **Limpeza local** não é um bypass: ele não altera logs de eventos, Sysmon ou rastros de auditoria do Windows.
- Os testes automatizados usam simulação dos processos e dispositivos de entrada; é necessário testar o comportamento final em Windows/Lunar real.

## Suporte

Em caso de `WinError 5` na compilação, feche `FlameV1_Free.exe` antes de recompilar. Se a porta 15700 estiver ocupada, feche versões anteriores do Love157 e Flame.
