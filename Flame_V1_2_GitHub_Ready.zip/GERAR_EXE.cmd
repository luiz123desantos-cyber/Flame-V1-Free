@echo off
setlocal EnableExtensions
chcp 65001 >nul 2>nul
cd /d "%~dp0" || exit /b 1
title FLAME V1.2 FREE - GERAR EXE
 echo ==========================================================
 echo           FLAME V1.2 FREE - GERAR EXE
 echo ==========================================================
if not exist "launcher.py" goto :MISSING
if not exist "flame_core.py" goto :MISSING
if not exist "windows_bridge.py" goto :MISSING
if not exist "service.py" goto :MISSING
if not exist "ui\index.html" goto :MISSING
if not exist "assets\flame.ico" goto :MISSING
where py >nul 2>nul
if not errorlevel 1 (set "PY=py -3") else (
 where python >nul 2>nul || goto :NO_PYTHON
 set "PY=python"
)
%PY% --version || goto :FAIL
%PY% -c "import PyInstaller, PIL" >nul 2>nul
if errorlevel 1 (
 echo O compilador precisa de PyInstaller e Pillow. Eles nao serao necessarios no PC de quem instalar.
 choice /C SN /M "Baixar e instalar dependencias de compilacao agora"
 if errorlevel 2 exit /b 2
 %PY% -m pip install --disable-pip-version-check pyinstaller pillow || goto :FAIL
) else (echo Dependencias de compilacao ja instaladas.)
if exist "dist\FlameV1_Free.exe" (
 echo Feche o Flame antes de substituir o EXE.
 tasklist /FI "IMAGENAME eq FlameV1_Free.exe" | find /I "FlameV1_Free.exe" >nul
 if not errorlevel 1 goto :EXE_RUNNING
)
echo Empacotando em um EXE autocontido (sem Python no PC de destino)...
%PY% -m PyInstaller --noconfirm --clean --onefile --windowed --name FlameV1_Free ^
 --icon "assets\flame.ico" --add-data "assets;assets" --add-data "ui;ui" ^
 --hidden-import flame_core --hidden-import service --hidden-import windows_bridge ^
 --distpath "dist" --workpath "build" --specpath "." "launcher.py"
if errorlevel 1 goto :FAIL
if not exist "dist\FlameV1_Free.exe" goto :FAIL
echo [OK] EXE gerado: %CD%\dist\FlameV1_Free.exe
echo Execute CRIAR_INSTALADOR.cmd para gerar o instalador com atalhos.
pause
exit /b 0
:MISSING
echo [ERRO] Arquivos do projeto ausentes. Extraia o ZIP completo.
pause
exit /b 1
:NO_PYTHON
echo Python nao encontrado, necessario SOMENTE para gerar o EXE.
choice /C SN /M "Abrir o site oficial do Python para baixar o instalador"
if errorlevel 2 exit /b 3
start "" "https://www.python.org/downloads/windows/"
exit /b 3
:EXE_RUNNING
echo [ERRO] Feche FlameV1_Free.exe antes de recompilar.
pause
exit /b 4
:FAIL
echo [ERRO] Falha no processo de geracao. Veja a mensagem acima.
pause
exit /b 5
