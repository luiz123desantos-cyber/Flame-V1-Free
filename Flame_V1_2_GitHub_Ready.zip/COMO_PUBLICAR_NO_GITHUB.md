# Publicação no GitHub

1. Crie um repositório **público** com o nome `Flame-V1-Free` em https://github.com/new.
2. Envie os arquivos desta pasta para o repositório (inclusive `.github/workflows/windows-build.yml`).
3. Na aba **Actions**, escolha **Windows build** e clique em **Run workflow**.
4. Após a conclusão, baixe os artefatos `.exe` e teste num computador Windows sem Python.
5. Depois dos testes, crie uma tag `v1.2.0-beta` na página de Releases, ou faça push dessa tag. A rotina de tag constrói e publica a prerelease automaticamente.
6. Verifique que a Release exibe os dois downloads e o aviso de beta.

**Observação:** o GitHub precisa estar configurado para permitir Actions, e o token de workflow precisa ter permissão para conteúdo (`contents: write`).
