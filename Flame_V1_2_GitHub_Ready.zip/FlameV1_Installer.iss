#define MyAppName "Flame V1 Free"
#define MyAppVersion "1.2.0"
#define MyAppExeName "FlameV1_Free.exe"

[Setup]
AppId={{A5A65DAB-94F5-4C3F-9119-967C0091640F}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppVerName={#MyAppName} {#MyAppVersion}
AppPublisher=Flame
DefaultDirName={localappdata}\Programs\Flame V1 Free
DefaultGroupName=Flame V1 Free
DisableProgramGroupPage=yes
OutputDir=installer
OutputBaseFilename=Flame_V1_Free_Setup
Compression=lzma2
SolidCompression=yes
PrivilegesRequired=lowest
WizardStyle=modern
SetupIconFile=assets\flame.ico
UninstallDisplayIcon={app}\{#MyAppExeName}
ArchitecturesAllowed=x64compatible

[Files]
Source: "dist\{#MyAppExeName}"; DestDir: "{app}"; Flags: ignoreversion

[Tasks]
Name: "desktopicon"; Description: "Criar atalho na área de trabalho"; GroupDescription: "Atalhos:"; Flags: checkedonce

[Icons]
Name: "{group}\Flame V1 Free"; Filename: "{app}\{#MyAppExeName}"
Name: "{group}\Desinstalar Flame V1 Free"; Filename: "{uninstallexe}"
Name: "{autodesktop}\Flame V1 Free"; Filename: "{app}\{#MyAppExeName}"; Tasks: desktopicon

[Run]
Filename: "{app}\{#MyAppExeName}"; Description: "Abrir Flame V1 Free"; Flags: nowait postinstall skipifsilent
