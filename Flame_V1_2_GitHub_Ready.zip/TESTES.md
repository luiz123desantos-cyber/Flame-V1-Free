# FLAME V1.2 FREE — Testes

- 17 testes Python automatizados: motor, validação, seleção de janela, foco, F11, F9, pausa, parada, perfis Legit e Blatant, endpoints locais autenticados, preferências e limpeza dos dados próprios.
- `python -m compileall` sem erros.
- JavaScript validado com `node --check`.
- Interface pré-visualizada no Chromium headless, com verificação da mudança dos sliders de 20 para 40 CPS conforme a seleção do perfil.
- **Ainda não testado no Windows/Lunar real nesta versão**, nem compilado um instalador Windows neste ambiente Linux.
