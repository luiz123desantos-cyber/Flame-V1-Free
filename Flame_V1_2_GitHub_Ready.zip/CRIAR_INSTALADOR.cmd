@echo off
setlocal EnableExtensions
chcp 65001 >nul 2>nul
cd /d "%~dp0" || exit /b 1
title FLAME V1 FREE - INSTALADOR
if not exist "dist\FlameV1_Free.exe" (
 echo Primeiro sera criado o EXE do aplicativo.
 call "%~dp0GERAR_EXE.cmd"
 if errorlevel 1 goto :ERROR
)
set "ISCC="
call :LOCATE_ISCC
if not defined ISCC (
 echo Inno Setup 6 nao encontrado. Necessario apenas para montar o instalador.
 choice /C SN /M "Deseja baixar/instalar o compilador Inno Setup usando winget"
 if errorlevel 2 exit /b 2
 where winget >nul 2>nul
 if errorlevel 1 (
   echo winget nao encontrado. Abrindo pagina oficial do Inno Setup.
   start "" "https://jrsoftware.org/isdl.php"
   exit /b 2
 )
 winget install --id JRSoftware.InnoSetup --exact --source winget --accept-package-agreements --accept-source-agreements
 if errorlevel 1 (
   echo winget nao concluiu a instalacao. Abrindo pagina oficial.
   start "" "https://jrsoftware.org/isdl.php"
   exit /b 2
 )
 call :LOCATE_ISCC
 if not defined ISCC (
   echo Inno Setup instalado, mas ISCC.exe nao localizado. Reabra o terminal e tente novamente.
   pause
   exit /b 2
 )
)
goto :MAKE_INSTALLER
:LOCATE_ISCC
if exist "%LOCALAPPDATA%\Programs\Inno Setup 6\ISCC.exe" set "ISCC=%LOCALAPPDATA%\Programs\Inno Setup 6\ISCC.exe"
if exist "%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe" set "ISCC=%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe"
if exist "%ProgramFiles%\Inno Setup 6\ISCC.exe" set "ISCC=%ProgramFiles%\Inno Setup 6\ISCC.exe"
if not defined ISCC (
 for %%I in (ISCC.exe) do if not "%%~$PATH:I"=="" set "ISCC=%%~$PATH:I"
)
exit /b 0
:MAKE_INSTALLER
echo Criando instalador usando Inno Setup...
"%ISCC%" "FlameV1_Installer.iss"
if errorlevel 1 goto :ERROR
if not exist "installer\Flame_V1_Free_Setup.exe" goto :ERROR
echo.
echo [OK] Instalador pronto: %CD%\installer\Flame_V1_Free_Setup.exe
start "" explorer.exe "%CD%\installer"
pause
exit /b 0
:ERROR
echo [ERRO] O instalador nao foi criado. Verifique as mensagens acima.
pause
exit /b 3
