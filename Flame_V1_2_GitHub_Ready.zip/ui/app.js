'use strict';
const $ = id => document.getElementById(id);
const token = document.querySelector('meta[name="flame-token"]').content;
let selectedHwnd = '';
let lastBindingGeneration = 0;
let settingsInitialized = false;
let activeProfile = 'legit';
let savedSpeeds = {legit:[11,11],blatant:[28,28]};
function updateSpeeds(){
 for(const [id,out] of [['lcps','lcpsout'],['rcps','rcpsout']]){
   $(out).textContent = `${$(id).value} CPS`;
 }
}
function applyProfile(profile,restore=true){
 activeProfile=profile;
 const max=profile==='blatant'?40:20;
 const speeds=savedSpeeds[profile];
 for(const [i,id] of ['lcps','rcps'].entries()){
   $(id).max=max;
   $(id).value=restore ? speeds[i] : Math.min(max,Number($(id).value));
 }
 $('left-max').textContent=`${max} CPS`;
 $('right-max').textContent=`${max} CPS`;
 $('profile-note').textContent = profile==='legit' ? 'Intervalos variáveis inspirados no jitter click. Não promete comportamento humano nem invisibilidade a anticheats.' : 'Intervalos rápidos e mais regulares. Alguns jogos podem limitar ou ignorar cliques excessivamente rápidos.';
 updateSpeeds();
}
for(const id of ['lcps','rcps']) $(id).addEventListener('input',()=>{
 savedSpeeds[activeProfile]=[Number($('lcps').value),Number($('rcps').value)];
 updateSpeeds();
});
for(const radio of document.querySelectorAll('input[name="click-profile"]')) radio.addEventListener('change',()=>{
 if(radio.checked)applyProfile(radio.value);
});
async function api(path,data){
 const opts=data===undefined ? {} : {method:'POST',headers:{'Content-Type':'application/json','X-Flame-Token':token},body:JSON.stringify(data)};
 const response=await fetch(path,opts);
 const result=await response.json();
 if(!response.ok)throw new Error(result.error||`HTTP ${response.status}`);
 return result;
}
function render(s){
 if(!settingsInitialized){
   settingsInitialized=true;
   const profile=s.click_profile==='blatant'?'blatant':'legit';
   savedSpeeds[profile]=[s.left_cps,s.right_cps];
   document.querySelector(`input[name="click-profile"][value="${profile}"]`).checked=true;
   applyProfile(profile);
   $('left-enabled').checked=!!s.left_enabled;
   $('right-enabled').checked=!!s.right_enabled;
   $('mode').value=s.mode||'sendinput';
 }
 const dropdown=$('process');
 const existing=String(dropdown.value||selectedHwnd||'');
 if(lastBindingGeneration!==s.binding_generation || !Array.from(dropdown.options).some(o=>o.value===existing)){
   selectedHwnd=String(s.selected_hwnd||'');
   lastBindingGeneration=s.binding_generation;
 }
 const chosen=selectedHwnd||existing;
 const options=s.windows||[];
 if(dropdown.options.length!==options.length || options.some(w=>!Array.from(dropdown.options).some(o=>o.value===String(w.hwnd)))){
   dropdown.replaceChildren();
   if(!options.length){const opt=document.createElement('option');opt.value='';opt.textContent='Nenhum cliente encontrado — use F9';dropdown.add(opt);}
   else for(const w of options){const opt=document.createElement('option');opt.value=String(w.hwnd);opt.textContent=`${w.client} · ${w.title} · PID ${w.pid}`;dropdown.add(opt);}
 }
 if(options.length){dropdown.value=chosen;if(dropdown.selectedIndex<0)dropdown.selectedIndex=0;}
 selectedHwnd=dropdown.value;
 $('clicks-left').textContent=s.clicks_left;
 $('clicks-right').textContent=s.clicks_right;
 $('foreground').textContent=s.foreground?'Sim':'Não';
 $('client').textContent=s.target_client||'Sem cliente vinculado';
 $('status-dot').classList.toggle('on',!!s.armed);
 $('status-label').textContent=s.armed?'ARMADO':'DESLIGADO';
 $('status').textContent=s.active_left&&s.active_right?'Clicando · LMB + RMB':s.active_left?'Clicando · LMB':s.active_right?'Clicando · RMB':s.recovering?'Aguardando janela após F11':s.armed?'Volte ao jogo e segure o botão':'Aguardando ativação';
 $('pause').textContent=s.manual_pause?'RETOMAR LMB · F7':'PAUSAR LMB · F7';
 $('message').textContent=s.error||s.notice||'';
}
async function refresh(force=false){try{render(await api(force?'/api/scan':'/api/status'));}catch(e){$('message').textContent=e.message;}}
$('process').addEventListener('change',()=>{selectedHwnd=$('process').value;});
$('scan').addEventListener('click',()=>refresh(true));
$('ready').addEventListener('click',async()=>{
 try{
  const hwnd=Number($('process').value);
  if(!hwnd)throw new Error('Abra o Minecraft e use F9 para vincular a janela, se necessário.');
  render(await api('/api/ready',{hwnd,left_cps:Number($('lcps').value),right_cps:Number($('rcps').value),left_enabled:$('left-enabled').checked,right_enabled:$('right-enabled').checked,mode:$('mode').value,click_profile:activeProfile}));
 }catch(e){$('message').textContent=e.message;}
});
$('reset-local').addEventListener('click',async()=>{
 if(!confirm('Apagar somente as preferências e contadores do Flame? Os registros de segurança do Windows não serão afetados.'))return;
 try{
  const s=await api('/api/reset-local',{});
  $('reset-message').textContent='Dados do Flame redefinidos. Logs do Windows preservados.';
  savedSpeeds={legit:[11,11],blatant:[28,28]};
  document.querySelector('input[name="click-profile"][value="legit"]').checked=true;
  applyProfile('legit');$('lcps').value=10;$('rcps').value=10;updateSpeeds();
  $('left-enabled').checked=true;$('right-enabled').checked=true;$('mode').value='sendinput';render(s);
 }catch(e){$('reset-message').textContent=e.message;}
});
$('pause').addEventListener('click',async()=>{try{render(await api('/api/pause',{}));}catch(e){$('message').textContent=e.message;}});
$('stop').addEventListener('click',async()=>{try{render(await api('/api/stop',{}));}catch(e){$('message').textContent=e.message;}});
refresh(true);
setInterval(()=>refresh(false),950);
setInterval(()=>refresh(true),4500);
