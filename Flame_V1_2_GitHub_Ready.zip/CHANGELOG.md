# Histórico de versões

## v1.2.0-beta

- Perfis Legit e Blatant para Auto Clicker LMB/RMB.
- Atualização da interface web Flame.
- Removida a pausa por cursor visível no inventário/menu.
- Recuperação de janela após F11 mantida.
- Preparação de instalador Windows com Inno Setup.
- Limpeza local restrita às preferências do próprio Flame.

### Conhecidas limitações

- Não validado em todos os launchers/clintes e versões do Windows.
- Modos sintéticos podem ser ignorados por jogos com Raw Input.
- A compatibilidade não é garantida.
