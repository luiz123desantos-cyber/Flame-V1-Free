import tempfile
import json
import sys
import threading
import time
import unittest
from pathlib import Path
from http.server import ThreadingHTTPServer
from urllib.error import HTTPError
from urllib.request import Request, urlopen

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from flame_core import Controller, make_handler, click_interval
from windows_bridge import game_window_guess


class FakeBridge:
    VK_LBUTTON, VK_RBUTTON = 1, 2
    VK_F6, VK_F7, VK_F8, VK_F9 = 117, 118, 119, 120

    def __init__(self):
        self.windows = [dict(pid=1111, hwnd=42, title='Minecraft 1.8.9',
                             exe=r'C:\Java\bin\javaw.exe', client='Minecraft', auto=True),
                        dict(pid=2222, hwnd=84, title='Lunar Client 1.8.9',
                             exe=r'C:\Lunar\Lunar Client.exe', client='Lunar Client', auto=True)]
        self.extra = dict(pid=3333, hwnd=99, title='Fabric private 1.8.9',
                          exe=r'C:\Custom\customgame.exe', client='Janela vinculada manualmente', auto=False)
        self.fg_hwnd = None
        self.keys = set()
        self.pulses = []
        self.releases = []
        self.lock = threading.Lock()
        self.show_cursor = False

    def list_game_windows(self):
        return list(self.windows)

    def valid_window(self, hwnd, pid):
        return any(w['hwnd']==hwnd and w['pid']==pid for w in self.windows + [self.extra])

    def recover_window(self, pid, previous_hwnd=None):
        # Mirrors Windows bridge: prefer the active HWND within the chosen PID.
        fg = next((w for w in self.windows+[self.extra]
                   if w['hwnd'] == self.fg_hwnd and w['pid'] == pid), None)
        if fg:
            return fg.copy()
        old = next((w for w in self.windows+[self.extra]
                    if w['pid'] == pid and w['hwnd'] == previous_hwnd), None)
        if old:
            return old.copy()
        same_pid = next((w for w in self.windows+[self.extra] if w['pid']==pid), None)
        return same_pid.copy() if same_pid else None

    def current_foreground_info(self):
        return next((w.copy() for w in self.windows+[self.extra] if w['hwnd']==self.fg_hwnd), None)

    def foreground_matches(self, hwnd, pid):
        return any(w['hwnd']==self.fg_hwnd and w['pid']==pid
                   for w in self.windows+[self.extra])

    def held(self, vk):
        return vk in self.keys

    def cursor_is_visible(self):
        return self.show_cursor

    def click_pulse(self, button, hwnd, mode):
        with self.lock:
            self.pulses.append((button, hwnd, mode, time.perf_counter()))

    def release(self, button, hwnd, mode):
        with self.lock:
            self.releases.append((button, hwnd, mode))

    def count(self, button):
        with self.lock:
            return sum(c[0]==button for c in self.pulses)


class ControllerTests(unittest.TestCase):
    def setUp(self):
        self.b = FakeBridge()
        self.c = Controller(self.b)
        self.c.scan()

    def tearDown(self):
        self.c.shutdown()

    def configure(self, hwnd=84, **overrides):
        cfg = dict(hwnd=hwnd, left_cps=20, right_cps=20, left_enabled=True,
                   right_enabled=True, mode='sendinput')
        cfg.update(overrides)
        self.c.configure(**cfg)

    def test_recognition(self):
        self.assertEqual(game_window_guess('Lunar Client 1.8.9', r'C:\Lunar\client.exe'), (True,'Lunar Client'))
        self.assertEqual(game_window_guess('Minecraft 1.8.9', r'C:\Java\javaw.exe'), (True,'Minecraft'))
        self.assertEqual(game_window_guess('Minecraft Launcher', r'C:\Program Files\Minecraft Launcher.exe'), (False,''))
        self.assertEqual(game_window_guess('Chrome', r'C:\Chrome\chrome.exe'), (False,''))
        self.assertEqual(game_window_guess('Badlion Client', r'C:\Badlion\launcher.exe'), (True,'Badlion Client'))

    def test_config_validation(self):
        for value in [0, 21, True, 1.5, '12']:
            with self.assertRaises(ValueError):
                self.configure(left_cps=value)
        with self.assertRaises(ValueError):
            self.configure(hwnd=999)
        with self.assertRaises(ValueError):
            self.configure(mode='inject')
        with self.assertRaises(ValueError):
            self.configure(left_enabled=False, right_enabled=False)

    def test_lunar_focus_and_both_buttons(self):
        self.configure()
        self.c.start()
        self.b.keys.update((1, 2))
        time.sleep(.09)
        self.assertEqual(self.b.count(1), 0)
        self.assertEqual(self.b.count(2), 0)
        self.b.fg_hwnd=84
        time.sleep(.21)
        self.assertGreaterEqual(self.b.count(1), 3)
        self.assertGreaterEqual(self.b.count(2), 3)
        self.b.fg_hwnd=42
        time.sleep(.06)
        old=self.b.count(1)
        time.sleep(.10)
        self.assertEqual(old, self.b.count(1))

    def test_f9_manual_bind_then_activate(self):
        self.configure(hwnd=42)
        self.b.fg_hwnd=99
        self.c.start()
        self.b.keys.add(self.b.VK_F9)
        time.sleep(.05)
        self.assertFalse(self.c.state()['armed'])
        self.assertEqual(self.c.state()['selected_hwnd'],99)
        self.assertGreater(self.c.state()['binding_generation'],0)
        self.assertTrue(any(w['hwnd']==99 for w in self.c.state()['windows']))
        self.b.keys.remove(self.b.VK_F9)
        self.configure(hwnd=99)
        self.b.keys.add(1)
        time.sleep(.13)
        self.assertGreaterEqual(self.b.count(1),1)

    def test_pause_and_stop(self):
        self.configure()
        self.b.fg_hwnd=84
        self.b.keys.update((1, 2))
        self.c.start()
        time.sleep(.12)
        self.b.keys.add(self.b.VK_F7)
        time.sleep(.04)
        l=self.b.count(1)
        r=self.b.count(2)
        time.sleep(.12)
        self.assertEqual(l,self.b.count(1))
        self.assertGreater(self.b.count(2),r)
        self.b.keys.add(self.b.VK_F8)
        time.sleep(.05)
        self.assertFalse(self.c.state()['armed'])
        r=self.b.count(2)
        time.sleep(.1)
        self.assertEqual(r,self.b.count(2))

    def test_window_temporarily_disappears_pauses_without_disarming(self):
        self.configure()
        self.b.windows = self.b.windows[:1]
        self.c.scan()
        s = self.c.state()
        self.assertTrue(s['armed'])
        self.assertTrue(s['recovering'])
        self.assertEqual(s['selected_pid'], 2222)
        self.assertNotEqual(s['selected_hwnd'], 42)

    def test_f11_replaces_hwnd_while_clicking_and_recovers(self):
        self.configure()
        self.b.fg_hwnd=84
        self.b.keys.add(1)
        self.c.start()
        time.sleep(.10)
        before = self.b.count(1)
        self.assertGreater(before, 0)
        self.b.windows = [w for w in self.b.windows if w['hwnd'] != 84]
        self.b.fg_hwnd = None
        self.c.scan()
        paused = self.b.count(1)
        time.sleep(.08)
        self.assertEqual(paused, self.b.count(1))
        self.assertTrue(self.c.state()['armed'])
        self.assertTrue(self.c.state()['recovering'])
        self.b.windows.append(dict(pid=2222, hwnd=108, title='', exe=r'C:\Lunar\Lunar Client.exe',
                                   client='', auto=False))
        self.b.fg_hwnd = 108
        self.c.scan()
        s = self.c.state()
        self.assertTrue(s['armed'])
        self.assertFalse(s['recovering'])
        self.assertEqual(s['selected_hwnd'], 108)
        self.assertEqual(s['target_client'], 'Lunar Client')
        self.assertGreater(s['binding_generation'], 0)
        time.sleep(.16)
        self.assertGreater(self.b.count(1), paused)

    def test_auto_recovery_never_migrates_to_another_pid(self):
        self.configure()
        self.b.windows = [w for w in self.b.windows if w['pid'] != 2222]
        self.b.fg_hwnd = 42
        self.c.scan()
        self.assertEqual(self.c.state()['selected_pid'],2222)
        self.assertTrue(self.c.state()['recovering'])
        self.assertFalse(self.c.state()['foreground'])
        self.b.keys.add(1)
        self.c.start()
        time.sleep(.10)
        self.assertEqual(self.b.count(1),0)

    def test_f11_in_place_handle_keeps_arm(self):
        self.configure()
        self.b.fg_hwnd=84
        self.b.windows[1]['title']=''
        self.b.windows[1]['auto']=False
        self.c.scan()
        self.assertTrue(self.c.state()['armed'])
        self.assertEqual(self.c.state()['selected_hwnd'],84)

    def test_message_mode(self):
        self.configure(mode='messages')
        self.b.fg_hwnd=84
        self.b.keys.add(1)
        self.c.start()
        time.sleep(.1)
        self.assertTrue(any(x[2]=='messages' for x in self.b.pulses))


class HttpTests(unittest.TestCase):
    def setUp(self):
        self.b=FakeBridge()
        self.c=Controller(self.b)
        self.c.scan()
        self.server=ThreadingHTTPServer(('127.0.0.1',0),make_handler(self.c, 'test-token'))
        self.thread=threading.Thread(target=self.server.serve_forever,daemon=True)
        self.thread.start()
        self.url=f'http://127.0.0.1:{self.server.server_port}'

    def tearDown(self):
        self.server.shutdown()
        self.server.server_close()
        self.thread.join(timeout=2)
        self.c.shutdown()

    def req(self,path,data=None,token=True,origin=None):
        if data is None:
            r=Request(self.url+path)
        else:
            headers={'Content-Type':'application/json'}
            if token: headers['X-Flame-Token']='test-token'
            if origin: headers['Origin']=origin
            r=Request(self.url+path,data=json.dumps(data).encode(),headers=headers,method='POST')
        return urlopen(r,timeout=2)

    def test_http_auth_and_config(self):
        self.assertIn('FLAME', self.req('/').read().decode())
        cfg=dict(hwnd=84,left_cps=11,right_cps=17,left_enabled=True,right_enabled=True,mode='sendinput')
        with self.assertRaises(HTTPError) as ex: self.req('/api/ready',cfg,token=False)
        self.assertEqual(ex.exception.code,403)
        with self.assertRaises(HTTPError) as ex: self.req('/api/ready',cfg,origin='http://attacker.test')
        self.assertEqual(ex.exception.code,403)
        s=json.load(self.req('/api/ready',cfg))
        self.assertTrue(s['armed'])
        self.assertEqual(s['target_client'],'Lunar Client')
        self.assertEqual(s['right_cps'],17)
        s=json.load(self.req('/api/pause',{}))
        self.assertTrue(s['manual_pause'])
        s=json.load(self.req('/api/stop',{}))
        self.assertFalse(s['armed'])



class FlameFeatureTests(unittest.TestCase):
    def test_legit_and_blatant_intervals_are_distinct(self):
        class FakeRng:
            def __init__(self): self.ranges=[]
            def uniform(self,low,high):
                self.ranges.append((low,high))
                return high
        fake=FakeRng()
        self.assertGreater(click_interval(10,'legit',fake),.1)
        self.assertEqual(fake.ranges[0],(.83,1.17))
        self.assertEqual(fake.ranges[1] if len(fake.ranges)>1 else None,None)
        fast=FakeRng()
        self.assertGreater(click_interval(30,'blatant',fast),.03)
        self.assertLess(click_interval(30,'blatant',fast),.04)
        self.assertEqual(fast.ranges[0],(.97,1.03))

    def test_blantant_accepts_40_but_legit_does_not(self):
        b=FakeBridge(); c=Controller(b); c.scan()
        c.configure(84,40,36,True,True,'sendinput','blatant')
        self.assertEqual(c.state()['click_profile'],'blatant')
        self.assertEqual(c.state()['left_cps'],40)
        with self.assertRaises(ValueError): c.configure(84,40,20,True,True,'sendinput','legit')
        with self.assertRaises(ValueError): c.configure(84,20,20,True,True,'sendinput','other')
        with self.assertRaises(ValueError): c.configure(84,41,20,True,True,'sendinput','blatant')
        c.shutdown()

    def test_ui_has_profiles_and_no_menu_guard(self):
        base=Path(__file__).resolve().parent.parent
        html=(base/'ui'/'index.html').read_text(encoding='utf-8')
        js=(base/'ui'/'app.js').read_text(encoding='utf-8')
        core=(base/'flame_core.py').read_text(encoding='utf-8')
        self.assertIn('LEGIT', html)
        self.assertIn('BLATANT', html)
        self.assertIn('click_profile', core)
        self.assertIn('X-Flame-Token', js)
        self.assertNotIn('menu-guard', html)
        self.assertNotIn('menu_guard', core)
        self.assertNotIn('Verifique as regras do servidor',html)
        self.assertTrue((base/'assets'/'flame.ico').exists())

    def test_cursor_visible_does_not_pause_clicks(self):
        b=FakeBridge();c=Controller(b);c.scan()
        c.configure(84,20,20,True,True,'sendinput','legit')
        b.fg_hwnd=84;b.keys.update((1,2));b.show_cursor=True
        c.start();time.sleep(.15)
        self.assertGreater(b.count(1),0)
        self.assertGreater(b.count(2),0)
        c.shutdown()

    def test_prefs_and_cleanup(self):
        with tempfile.TemporaryDirectory() as d:
            prefs=Path(d)/'FlameV1Free'/'preferences.json'
            unrelated=Path(d)/'other_program.txt'
            unrelated.write_text('KEEP')
            b=FakeBridge(); c=Controller(b,preferences_path=prefs);c.scan()
            c.configure(84,33,35,True,True,'sendinput','blatant')
            self.assertTrue(prefs.exists())
            restored=Controller(b,preferences_path=prefs)
            self.assertEqual(restored.click_profile,'blatant')
            self.assertEqual(restored.left_cps,33)
            c.clicks_left=10
            self.assertTrue(c.reset_local_data())
            self.assertEqual(c.clicks_left,0)
            self.assertFalse(prefs.exists())
            self.assertTrue(unrelated.exists())
            c.shutdown();restored.shutdown()

    def test_reset_endpoint_requires_token(self):
        b=FakeBridge()
        with tempfile.TemporaryDirectory() as d:
            c=Controller(b,preferences_path=Path(d)/'preferences.json');c.scan()
            c.configure(84,10,10,True,True,'sendinput','legit')
            srv=ThreadingHTTPServer(('127.0.0.1',0),make_handler(c,'secret'))
            t=threading.Thread(target=srv.serve_forever,daemon=True);t.start()
            url=f'http://127.0.0.1:{srv.server_port}/api/reset-local'
            try:
                with self.assertRaises(HTTPError) as ctx:
                    urlopen(Request(url,data=b'{}',headers={'Content-Type':'application/json'},method='POST'),timeout=2)
                self.assertEqual(ctx.exception.code,403)
                r=urlopen(Request(url,data=b'{}',headers={'Content-Type':'application/json','X-Flame-Token':'secret'},method='POST'),timeout=2)
                self.assertEqual(r.status,200)
                self.assertFalse(c.preferences_path.exists())
            finally:
                srv.shutdown();srv.server_close();t.join(timeout=2);c.shutdown()

if __name__=='__main__':
    unittest.main()
