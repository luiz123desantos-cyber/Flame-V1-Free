@echo off
setlocal
cd /d "%~dp0"
py -3 launcher.py
if errorlevel 1 (
 echo [ERRO] Nao foi possivel iniciar. Confira Python e Pillow.
 pause
)
