# 🔥 Flame V1.2 Free — Public Beta

Auto Clicker de uso local para Windows 10/11, com painel no navegador em `http://127.0.0.1:15700`.

> **Status: Beta.** As funções foram testadas com simulações automatizadas; compatibilidade final com Lunar, Vanilla e outros clientes precisa ser validada em computadores Windows reais. O uso pode contrariar regras de servidores.

## Funcionalidades

- Auto Click LMB / RMB separados.
- Perfil **Legit** (1 a 20 CPS, intervalos variáveis) e **Blatant** (1 a 40 CPS, intervalos mais regulares). Os nomes descrevem padrões, não prometem burlar detecção.
- Detecção de janelas de Minecraft, Lunar e outros clientes.
- Recuperação automática de janela depois do F11 (quando permanece no mesmo PID).
- Atalhos: F6 liga/desliga; F7 pausa clique esquerdo; F8 para; F9 vincula janela atual.
- Painel web local, sem serviço remoto.
- Limpeza **apenas das configurações do próprio Flame**. Não apaga logs/auditorias do Windows.

## Instalar

No [Releases](../../releases), baixe `Flame_V1_Free_Setup.exe` quando disponível, execute o instalador e, se desejar, marque o atalho na área de trabalho. O instalador já inclui o Python necessário — o usuário final não precisa instalá-lo.

Em alternativa, use `FlameV1_Free.exe` portátil no Release.

## Usar

1. Inicie o Flame e clique em **ABRIR PAINEL**.
2. Entre no Minecraft/Lunar e escolha a janela correspondente no painel.
3. Ajuste perfil, CPS e os botões LMB/RMB.
4. Clique **PRONTO — ATIVAR** e volte ao jogo.

O programa envia cliques sintéticos somente quando a janela selecionada está em foco. Clientes podem bloquear ou ignorar esses eventos.

## Compilar a partir do código

Requer Python 3 instalado no PC que compila. Execute `GERAR_EXE.cmd` e, para criar o instalador, `CRIAR_INSTALADOR.cmd` (Inno Setup 6). Os scripts perguntam antes de instalar ferramentas que faltam.

Você também pode abrir a aba **Actions** para executar o workflow **Windows build**. Ele gera os dois executáveis como artefatos. Tags no formato `v*` publicam automaticamente uma Release de pré-lançamento.

## Testes

`python -m unittest discover -s tests -v`

17 testes automatizados passaram na última validação de desenvolvimento (ambiente Linux com dispositivos simulados).

## Avisos

- Não há injeção, DLL, Forge ou Java Agent nesta versão.
- O painel só escuta em `127.0.0.1` e usa token local para alterações.
- Não estão incluídas funções de bypass de anticheat ou apagamento de rastros de auditoria.
- A distribuição pública deve ser acompanhada de uma análise antivírus e testes em um Windows limpo.

## Código e licença

O projeto está disponível para inspeção. Nenhuma licença de redistribuição do código foi escolhida até o proprietário definir uma (sem arquivo LICENSE).
