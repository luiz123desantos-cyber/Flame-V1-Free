"""Windows game window discovery and non-invasive input bridge.

No DLL injection, drivers, process memory access or Java dependency.
"""
from __future__ import annotations

import ctypes
from ctypes import wintypes
from pathlib import PureWindowsPath

GAME_TERMS = ('minecraft', 'lunar client', 'badlion', 'feather client',
              'labymod', 'salwyrr', 'lunarclient')
GAME_PROCESSES = {'java.exe', 'javaw.exe', 'minecraft.exe', 'lunarclient.exe',
                  'lunar client.exe', 'badlion client.exe', 'feather client.exe',
                  'labymod.exe'}
EXCLUDED_TITLES = ('minecraft launcher', 'lunar client launcher',
                   'badlion launcher', 'feather launcher', 'tlauncher')


def game_window_guess(title: str, image: str) -> tuple[bool, str]:
    """Conservative suggestions; F9 manual binding handles unusual clients."""
    t = title.casefold().strip()
    name = PureWindowsPath(image).name.casefold()
    if not t or any(x in t for x in EXCLUDED_TITLES):
        return False, ''
    if 'lunar' in t or 'lunarclient' in name:
        return True, 'Lunar Client'
    if 'badlion' in t or 'badlion' in name:
        return True, 'Badlion Client'
    if 'feather' in t or 'feather' in name:
        return True, 'Feather Client'
    if 'labymod' in t:
        return True, 'LabyMod'
    if 'salwyrr' in t:
        return True, 'Salwyrr'
    if 'minecraft' in t:
        return True, 'Minecraft'
    if name in GAME_PROCESSES and any(x in t for x in ('1.8.9', '1.12.2', '1.16', '1.20', '1.21')):
        return True, 'Java / Minecraft'
    return False, ''


class WindowsBridge:
    VK_LBUTTON, VK_RBUTTON = 0x01, 0x02
    VK_F6, VK_F7, VK_F8, VK_F9 = 0x75, 0x76, 0x77, 0x78
    PROCESS_QUERY_LIMITED_INFORMATION = 0x1000
    INPUT_MOUSE = 0
    MOUSEEVENTF_LEFTDOWN, MOUSEEVENTF_LEFTUP = 0x0002, 0x0004
    MOUSEEVENTF_RIGHTDOWN, MOUSEEVENTF_RIGHTUP = 0x0008, 0x0010
    WM_LBUTTONDOWN, WM_LBUTTONUP = 0x0201, 0x0202
    WM_RBUTTONDOWN, WM_RBUTTONUP = 0x0204, 0x0205
    MK_LBUTTON, MK_RBUTTON = 0x0001, 0x0002
    CURSOR_SHOWING = 0x00000001

    def __init__(self):
        if not hasattr(ctypes, 'WinDLL'):
            raise RuntimeError('O Flame V1 precisa do Windows 10/11.')
        self.user32 = ctypes.WinDLL('user32', use_last_error=True)
        self.kernel32 = ctypes.WinDLL('kernel32', use_last_error=True)
        u, k = self.user32, self.kernel32
        u.EnumWindows.argtypes = [ctypes.c_void_p, wintypes.LPARAM]
        u.EnumWindows.restype = wintypes.BOOL
        u.IsWindowVisible.argtypes = [wintypes.HWND]
        u.IsWindowVisible.restype = wintypes.BOOL
        u.IsIconic.argtypes = [wintypes.HWND]
        u.IsIconic.restype = wintypes.BOOL
        u.IsWindow.argtypes = [wintypes.HWND]
        u.IsWindow.restype = wintypes.BOOL
        u.GetWindowTextLengthW.argtypes = [wintypes.HWND]
        u.GetWindowTextLengthW.restype = ctypes.c_int
        u.GetWindowTextW.argtypes = [wintypes.HWND, wintypes.LPWSTR, ctypes.c_int]
        u.GetWindowTextW.restype = ctypes.c_int
        u.GetWindowThreadProcessId.argtypes = [wintypes.HWND, ctypes.POINTER(wintypes.DWORD)]
        u.GetWindowThreadProcessId.restype = wintypes.DWORD
        u.GetForegroundWindow.argtypes = []
        u.GetForegroundWindow.restype = wintypes.HWND
        u.GetAsyncKeyState.argtypes = [ctypes.c_int]
        u.GetAsyncKeyState.restype = ctypes.c_short
        u.PostMessageW.argtypes = [wintypes.HWND, wintypes.UINT, wintypes.WPARAM, wintypes.LPARAM]
        u.PostMessageW.restype = wintypes.BOOL
        u.GetCursorPos.argtypes = [ctypes.POINTER(wintypes.POINT)]
        u.GetCursorPos.restype = wintypes.BOOL
        u.ScreenToClient.argtypes = [wintypes.HWND, ctypes.POINTER(wintypes.POINT)]
        u.ScreenToClient.restype = wintypes.BOOL
        k.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
        k.OpenProcess.restype = wintypes.HANDLE
        k.QueryFullProcessImageNameW.argtypes = [wintypes.HANDLE, wintypes.DWORD, wintypes.LPWSTR, ctypes.POINTER(wintypes.DWORD)]
        k.QueryFullProcessImageNameW.restype = wintypes.BOOL
        k.CloseHandle.argtypes = [wintypes.HANDLE]
        k.CloseHandle.restype = wintypes.BOOL

        ULONG_PTR = ctypes.c_ulonglong if ctypes.sizeof(ctypes.c_void_p) == 8 else ctypes.c_ulong
        class MOUSEINPUT(ctypes.Structure):
            _fields_ = [('dx', wintypes.LONG), ('dy', wintypes.LONG), ('mouseData', wintypes.DWORD),
                        ('dwFlags', wintypes.DWORD), ('time', wintypes.DWORD), ('dwExtraInfo', ULONG_PTR)]
        class InputUnion(ctypes.Union):
            _fields_ = [('mi', MOUSEINPUT)]
        class INPUT(ctypes.Structure):
            _anonymous_ = ('payload',)
            _fields_ = [('type', wintypes.DWORD), ('payload', InputUnion)]
        self._INPUT, self._MOUSEINPUT, self._InputUnion = INPUT, MOUSEINPUT, InputUnion
        u.SendInput.argtypes = [wintypes.UINT, ctypes.POINTER(INPUT), ctypes.c_int]
        u.SendInput.restype = wintypes.UINT
        class CURSORINFO(ctypes.Structure):
            _fields_ = [('cbSize', wintypes.DWORD), ('flags', wintypes.DWORD),
                        ('hCursor', wintypes.HANDLE), ('ptScreenPos', wintypes.POINT)]
        self._CURSORINFO = CURSORINFO
        u.GetCursorInfo.argtypes = [ctypes.POINTER(CURSORINFO)]
        u.GetCursorInfo.restype = wintypes.BOOL

    def _exe(self, pid: int) -> str:
        handle = self.kernel32.OpenProcess(self.PROCESS_QUERY_LIMITED_INFORMATION, False, pid)
        if not handle:
            return ''
        try:
            b = ctypes.create_unicode_buffer(2048)
            n = wintypes.DWORD(len(b))
            if self.kernel32.QueryFullProcessImageNameW(handle, 0, b, ctypes.byref(n)):
                return b.value
            return ''
        finally:
            self.kernel32.CloseHandle(handle)

    def _window_info(self, hwnd: int, allow_blank: bool = False):
        if not hwnd or not self.user32.IsWindow(hwnd) or not self.user32.IsWindowVisible(hwnd):
            return None
        n = self.user32.GetWindowTextLengthW(hwnd)
        if n <= 0 and not allow_blank:
            return None
        buf = ctypes.create_unicode_buffer(max(n + 1, 1))
        if n > 0:
            self.user32.GetWindowTextW(hwnd, buf, n + 1)
        pid = wintypes.DWORD()
        self.user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
        if not pid.value:
            return None
        exe = self._exe(pid.value)
        matched, kind = game_window_guess(buf.value, exe)
        return {'pid': int(pid.value), 'hwnd': int(hwnd), 'title': buf.value,
                'exe': exe, 'client': kind or 'Janela vinculada manualmente',
                'auto': matched}

    def list_game_windows(self):
        found = []
        callback_type = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)
        @callback_type
        def cb(hwnd, _):
            if len(found) >= 50 or self.user32.IsIconic(hwnd):
                return True
            info = self._window_info(hwnd)
            if info and info['auto']:
                found.append(info)
            return True
        if not self.user32.EnumWindows(cb, 0):
            raise OSError(ctypes.get_last_error(), 'Não foi possível listar janelas.')
        return found

    def current_foreground_info(self):
        return self._window_info(self.user32.GetForegroundWindow(), allow_blank=True)

    def valid_window(self, hwnd: int, pid: int) -> bool:
        w = self._window_info(hwnd, allow_blank=True)
        return w is not None and w['pid'] == pid

    def recover_window(self, pid: int, previous_hwnd: int | None = None):
        """Find a replacement HWND belonging to the SAME process after F11.

        Never select another process merely because its title looks like Minecraft.
        Fullscreen windows can temporarily have no title, so this explicitly
        supports untitled windows for an already-confirmed game PID only.
        """
        if not pid:
            return None
        fg = self._window_info(self.user32.GetForegroundWindow(), allow_blank=True)
        if fg and fg['pid'] == pid and not self.user32.IsIconic(fg['hwnd']):
            return fg

        possible = []
        callback_type = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)
        @callback_type
        def cb(hwnd, _):
            if self.user32.IsIconic(hwnd):
                return True
            candidate = self._window_info(hwnd, allow_blank=True)
            if candidate and candidate['pid'] == pid:
                possible.append(candidate)
            return True
        self.user32.EnumWindows(cb, 0)
        if not possible:
            return None
        # Prefer the old valid handle, then a labeled game window, not a
        # nameless helper window that may belong to the same process.
        return sorted(possible, key=lambda w: (
            w['hwnd'] != previous_hwnd,
            not w['auto'],
            not bool(w['title']),
        ))[0]

    def foreground_matches(self, hwnd: int, pid: int) -> bool:
        fg = self.user32.GetForegroundWindow()
        if not fg:
            return False
        if int(fg) == hwnd:
            return True
        # Some clients use different top-level game window handles in the same process.
        active_pid = wintypes.DWORD()
        self.user32.GetWindowThreadProcessId(fg, ctypes.byref(active_pid))
        return int(active_pid.value) == pid

    def cursor_is_visible(self):
        """Retorna True/False ou None se o Windows não informou o estado."""
        info = self._CURSORINFO()
        info.cbSize = ctypes.sizeof(self._CURSORINFO)
        if not self.user32.GetCursorInfo(ctypes.byref(info)):
            return None
        return bool(info.flags & self.CURSOR_SHOWING)

    def held(self, vk: int) -> bool:
        return bool(self.user32.GetAsyncKeyState(vk) & 0x8000)

    def _send(self, flags: int):
        mi = self._MOUSEINPUT(0, 0, 0, flags, 0, 0)
        obj = self._INPUT(type=self.INPUT_MOUSE, payload=self._InputUnion(mi=mi))
        if self.user32.SendInput(1, ctypes.byref(obj), ctypes.sizeof(self._INPUT)) != 1:
            raise OSError(ctypes.get_last_error(), 'SendInput falhou. Verifique permissões e foco.')

    def _post(self, hwnd: int, button: int, up: bool):
        pos = wintypes.POINT()
        self.user32.GetCursorPos(ctypes.byref(pos))
        self.user32.ScreenToClient(hwnd, ctypes.byref(pos))
        lparam = (pos.x & 0xffff) | ((pos.y & 0xffff) << 16)
        if button == self.VK_LBUTTON:
            msg = self.WM_LBUTTONUP if up else self.WM_LBUTTONDOWN
            mask = 0 if up else self.MK_LBUTTON
        else:
            msg = self.WM_RBUTTONUP if up else self.WM_RBUTTONDOWN
            mask = 0 if up else self.MK_RBUTTON
        if not self.user32.PostMessageW(hwnd, msg, mask, lparam):
            raise OSError(ctypes.get_last_error(), 'PostMessage falhou.')

    def click_pulse(self, button: int, hwnd: int, mode: str):
        if button == self.VK_LBUTTON:
            up, down = self.MOUSEEVENTF_LEFTUP, self.MOUSEEVENTF_LEFTDOWN
        elif button == self.VK_RBUTTON:
            up, down = self.MOUSEEVENTF_RIGHTUP, self.MOUSEEVENTF_RIGHTDOWN
        else:
            raise ValueError('Botão inválido')
        if mode == 'messages':
            self._post(hwnd, button, True)
            self._post(hwnd, button, False)
        else:
            self._send(up)
            self._send(down)

    def release(self, button: int, hwnd: int, mode: str):
        if mode == 'messages':
            if hwnd and self._window_info(hwnd):
                self._post(hwnd, button, True)
        else:
            self._send(self.MOUSEEVENTF_LEFTUP if button == self.VK_LBUTTON else self.MOUSEEVENTF_RIGHTUP)
